package util;

public class SendMail {

}
