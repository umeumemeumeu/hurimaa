package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ListingServlet {

	//doGetメソッドを定義
	public void doGet(HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException{

		String error = "";
		String cmd = "";

		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			//パラメータの取得
			String a= request.getParameter("");
			String  b= request.getParameter("");
			String  c= request.getParameter("");

		}catch(Exception e){

		}finally {

		}
	}

	}
