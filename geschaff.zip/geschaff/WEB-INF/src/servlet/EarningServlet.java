package servlet;

public class EarningServlet {

}
