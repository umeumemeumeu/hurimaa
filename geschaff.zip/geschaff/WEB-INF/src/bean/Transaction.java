package bean;

public class Transaction {

}
