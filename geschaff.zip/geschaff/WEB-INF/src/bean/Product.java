package bean;

public class Product {

}
