package bean;

public class Admin {

}
